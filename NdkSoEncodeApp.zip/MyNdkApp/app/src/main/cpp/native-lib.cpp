#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_leo_myapplication_MainActivity_stringFromJNI2(
        JNIEnv *env,
        jobject /* this */) {
    char* hello = "Hello from C++!!";
    char* h = "1";

    int size = strlen(hello) + strlen(h);
    char *n_char = new char[size + 1];
        strcpy(n_char, hello);
    strcat(n_char, h);
    return env->NewStringUTF(hello);
}
